# Section 10: The Real World

There are no lecture notes in this section, only a real life example on how to build a website using AWS and WordPress.
